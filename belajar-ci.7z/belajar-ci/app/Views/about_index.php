<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ABOUT</title>
</head>

<body>
    <h1>Ini adalah Halaman About </h1>
</body>

</html>